/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugasdesktopgui;

/**
 *
 * @author HP
 */
public class TugasDesktopGUI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Input inp = new Input();
        inp.setVisible(true);
        inp.pack();
        inp.setLocationRelativeTo(null);
        inp.setDefaultCloseOperation(Input.EXIT_ON_CLOSE);
    }
}
